<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Attendance List</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo asset("packages/css/bootstrap.min.css"); ?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo asset("packages/css/plugins/metisMenu/metisMenu.min.css"); ?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo asset("packages/css/sb-admin-2.css"); ?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo asset("packages/css/font-awesome.min.css"); ?>" rel="stylesheet" type="text/css">

    <!-- DataTables CSS -->
    <link href="<?php echo asset("packages/css/plugins/dataTables.bootstrap.css"); ?>" rel="stylesheet">
	
	<!-- jQuery Version 1.11.0 -->
    <script src="<?php echo asset("packages/js/jquery-1.11.0.js"); ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo asset("packages/js/bootstrap.min.js"); ?>"></script>

	<!-- DataTables JavaScript -->
    <script src="<?php echo asset("packages/js/plugins/dataTables/jquery.dataTables.js"); ?>"></script>
    <script src="<?php echo asset("packages/js/plugins/dataTables/dataTables.bootstrap.js"); ?>"></script>
	
	
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Student Test Project</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li class="divider"></li>
                        <li><a href="{{ asset('/logout') }}"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="{{ asset('attendance/create') }}"><i class="fa fa-dashboard fa-fw"></i> Create Attendance</a>
                        </li>
						<li>
                            <a href="{{ asset('attendance/list') }}"><i class="fa fa-dashboard fa-fw"></i> Attendance List</a>
                        </li>
                        @if(Session::get('role')!= "2")
							<li>
								<a href="{{ asset('invoice/create') }}"><i class="fa fa-dashboard fa-fw"></i> Create Invoice</a>
							</li>
							<li>
								<a href="{{ asset('invoice/list') }}"><i class="fa fa-dashboard fa-fw"></i> Invoice List</a>
							</li>
						@endif
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Attendance List Page</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
			@if(Session::has('error'))
				<div style="color: #900; font-size: 18px;font-style: italic;margin-top: -1px; margin-bottom: 15px;">{{ Session::get('error') }}</div>
			@endif
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Attendance Table 
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive" id="attendence">                                				
									<table class="table table-striped table-bordered table-hover" id="dataTable">
                                    <thead>																	
                                        <tr>
										@if(Session::get('role')!= "2")
                                            <th>
												<div class="checkbox">
													<label>
														<input type="checkbox" value="">
													</label>
												</div>
											</th>
										@endif
                                            <th>Student Name</th>
                                            <th>Course Name</th>
											<th>Status</th>
                                            <th>Created Date</th>
											<th>Updated Date</th>
                                            <th>Function</th>
                                        </tr>
										
                                    </thead>
									<tbody>
										@foreach($attendances as $attendance)
										<tr>
										@if(Session::get('role')!="2")
											<td>
												<div class="checkbox">
													<label>
														<input type="checkbox" class="attendanceId" name="attendanceId[]" value="{{ $attendance->id }}">
													</label>
												</div>
											</td>
										@endif
											<td>{{ $attendance->userName }}</td>
											<td>{{ $attendance->name }}</td>
											<td>{{ $attendance->status }}</td>
											<td>{{ $attendance->created_at }}</td>
											<td>{{ $attendance->updated_at }}</td>
											<td><a href="{{ asset('attendance/edit').'/'.$attendance->id }}" style="margin-right: 10px;"><i class="fa fa-edit"></i></a><a href="{{ asset('attendance/delete').'/'.$attendance->id }}"><i class="fa fa-times"></i></a></td>
										</tr>@endforeach
									</tbody>
										
                                </table>
								@if(Session::get('role')!="2")
									<button name="disapproved" id="disapproved" class="btn btn-default">Disapproved</button>
									<button name="approved" id="approved" class="btn btn-primary">Approved</button>
								@endif
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo asset("packages/js/plugins/metisMenu/metisMenu.min.js"); ?>"></script>

    

    <!-- Custom Theme JavaScript -->
	<script src="<?php echo asset("packages/js/sb-admin-2.js"); ?>"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    

</body>
<script>
		$(document).ready(function() {
			$('#dataTable').dataTable();
			var root = '{{url("/")}}';
			
			$('#approved').click(function(){
				
				var checkedArray= [];
				$('.attendanceId:checked').each(function(){
					checkedArray.push($(this).val());
				});
				
				$.ajax({
					type: "POST",
					url: root+'/attendance/approved',
					data: {"data": checkedArray},
					success: function (data) {
							window.location.reload(true);
						}
				});
	
			});
			
			$('#disapproved').click(function(){
				var checkedArray= [];
				$('.attendanceId:checked').each(function(){
					checkedArray.push($(this).val());
				});
				
				$.ajax({
					type: "POST",
					url: root+'/attendance/disapproved',
					data: {"data": checkedArray},
					success: function (data) {
							window.location.reload(true);
						}
				});
			});
		});
    </script>
</html>
