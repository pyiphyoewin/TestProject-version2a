<?php

class Invoice extends Eloquent
{
	protected $table = 'invoices';
}