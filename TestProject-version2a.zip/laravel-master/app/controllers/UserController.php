<?php

class UserController extends BaseController {
	
}
