<?php

class CourseController extends BaseController {

	
}
