<?php

class InvoiceController extends BaseController {
	
	public function __construct()
	{
		$this->beforeFilter('auth',array('except' => 'auth/login'));
	}
	
	public function getCreate()
	{	
		if(Session::get('role')!="2"){
			$flag = "create";
			$courses = Course::all();
			$users = User::where('role','=',"2")->get();
			$checkUser = new User;
			$checkCourse = new Course;
			return View::make('Invoice.invoiceCreate', array('checkUser' => $checkUser,'checkCourse' => $checkCourse,'users' => $users, 'courses' => $courses, 'flag' => $flag));
		}
		return Redirect::to('/logout');
	}
	
	public function postCreate(){
		$enrolls = DB::table('user_course')
				->where('userId','=',Input::get('userId'))
				->where('courseId','=',Input::get('courseId'))
				->get();
		if(empty($enrolls)){
			Session::flash('error',"This student did not enroll to this course!");
			return Redirect::to('invoice/create')->withInput();
		}
		
		$data = Input::all();
		Session::flash('values', $data);
		Session::put('flag', 'create');
		return Redirect::to('invoice/confirm');
	}
	
	public function courseFee($startDate, $endDate, $userId, $courseId, $monthlyFee, $sessionFee){
		$attendances = DB::table('attendances')
					->where('userId','=',$userId)
					->where('courseId','=',$courseId)
					->where('status','=',"approved")
					->whereBetween('created_at',array($startDate,$endDate))
					->get();
		
		$numberOfSessions = count($attendances);
		
		if($numberOfSessions == 7 || $numberOfSessions == 6){
			$amount = $monthlyFee + ($sessionFee * $numberOfSessions);
		}else{
			$amount = $monthlyFee + ($sessionFee * 8);
		}
		 $data = array('numberOfSessions' => $numberOfSessions, 'amount' => $amount);
		return $data;
	}
	
	public function dataList($oldData){
		$enrolls = DB::table('user_course')
					->where('userId','=',$oldData['userId'])
					->where('courseId','=',$oldData['courseId'])
					->get();
		foreach($enrolls as $enroll){
			$user = User::find($oldData['userId']);
			$course = Course::find($enroll->courseId);
			
			$startDateOfLastTwoMonth = date('Y-m-d', strtotime('first day of -2 month'));
			$endDateOfLastTwoMonth = date('Y-m-d', strtotime('last day of -2 month'));
			
			$startDateOfLastMonth = date('Y-m-d', strtotime('first day of -1 month'));
			$endDateOfLastMonth = date('Y-m-d', strtotime('last day of -1 month'));
			
			$startDateOfThisMonth = date('Y-m-01');
			$endDateOfThisMonth = date('Y-m-t');
			
			$lastTwoMonthData = $this->courseFee($startDateOfLastTwoMonth, $endDateOfLastTwoMonth, $user->id, $course->id, $course->monthlyFee, $course->sessionFee);
			$lastMonthData = $this->courseFee($startDateOfLastMonth, $endDateOfLastMonth, $user->id, $course->id, $course->monthlyFee, $course->sessionFee);
			$thisMonthData = $this->courseFee($startDateOfThisMonth, $endDateOfThisMonth, $user->id, $course->id, $course->monthlyFee, $course->sessionFee);
			
			$totalSession = $lastTwoMonthData['numberOfSessions'] + $lastMonthData['numberOfSessions'] + $thisMonthData['numberOfSessions'];
			$totalAmount = $lastTwoMonthData['amount'] + $lastMonthData['amount'] + $thisMonthData['amount'];
			/*
			$lastTwoMonthAttendances = DB::table('attendances')
					->where('userId','=',$oldData['userId'])
					->where('courseId','=',$oldData['courseId'])
					->where('status','=',"approved")
					->whereBetween('created_at',array($startDateOfLastTwoMonth,$endDateOfLastTwoMonth))
					->get();
		
			$lastTwoMonthSesions = count($lastTwoMonthAttendances);
		
			if($lastTwoMonthSesions == 7 || $lastTwoMonthSesions == 6){
				$amount = $course->monthlyFee + ($course->sessionFee * $lastTwoMonthSesions);
			}else{
				$amount = $course->monthlyFee + ($course->sessionFee * 8);
			}*/
		
			$dataList = array('userId' => $user->id , 'userName' => $user->name, 'courseId' =>$course->id, 'courseName' => $course->name, 
			'sessions' => $totalSession, 'startDate' => $startDateOfLastTwoMonth, 'endDate' => $endDateOfThisMonth, 'fees' => $totalAmount);
			return $dataList;
		}				
	}
	
	public function getConfirm(){
		if(Session::get('role') != "2"){
			if(Session::get('flag') == "delete"){
			
				$invoice = Invoice::find(Session::get('id'));
				$user = User::find($invoice->userId);
				$course = Course::find($invoice->courseId);
				$oldData = array('invoiceId' => $invoice->id);
				$dataList = array('userId' => $invoice->userId , 'userName' => $user->name, 'courseId' => $invoice->courseId, 'courseName' => $course->name, 
					'sessions' => $invoice->sessions, 'startDate' => $invoice->startDate, 'endDate' => $invoice->endDate, 'fees' => $invoice->fees);
				return View::make('Invoice.invoiceConfirm', array('oldData' =>$oldData, 'data' => $dataList));
			}
			
			$oldData = Session::get('values');
			$dataList = $this->dataList($oldData);
			return View::make('Invoice.invoiceConfirm', array('oldData' =>$oldData, 'data' => $dataList));
		}else{
			return Redirect::to('/logout');
		}
		
	}
	
	public function postConfirm(){
		if(Session::get('flag') == "delete"){
			$invoice = Invoice::find(Input::get('invoiceId'));
			$invoice->delete();
			return Redirect::to('invoice/list');
		}elseif(Session::get('flag') == "create"){
			$invoice = new Invoice;
		}else{
			$invoice = Invoice::find(Input::get('invoiceId'));
		}
		$invoice->userId = Input::get('userId');
		$invoice->courseId = Input::get('courseId');
		$invoice->sessions = Input::get('sessions');
		$invoice->startDate = Input::get('startDate');
		$invoice->endDate = Input::get('endDate');
		$invoice->fees = Input::get('fees');
		$invoice->save();

		Session::forget('flag');
		return Redirect::to('invoice/list');
	}
	
	public function getList(){		
		if(Session::get('role') != "2"){
			$invoices = DB::table('invoices')
				->join('users','userId','=','users.id')
				->join('courses','courseId','=','courses.id')
				->select('invoices.id','users.name as userName','courses.name','invoices.sessions','invoices.startDate','invoices.endDate','invoices.fees','invoices.created_at','invoices.updated_at')
				->get();
			return View::make('Invoice.invoiceList')->with('invoices',$invoices);
		}else{
			return Redirect::to('/logout');
		}
	}
	
	public function getEdit($id){
		if(Session::get('role') != "2"){
			$flag="edit";
			$invoice = Invoice::find($id);
			$checkUser = User::find($invoice->userId);
			$users = User::all();
			$checkCourse = Course::find($invoice->courseId);
			$courses = Course::all();
			return View::make('Invoice.invoiceCreate', array('invoiceId' => $id,'checkUser' => $checkUser,'users' => $users, 'checkCourse' => $checkCourse,'courses' => $courses, 'flag' => $flag));
		}else{
			return Redirect::to('/logout');
		}
	}
	
	public function postEdit(){
		$data = Input::all();
		Session::flash('values', $data);
		Session::put('flag', 'edit');
		return Redirect::to('invoice/confirm');
	}
	
	public function getDelete($id){
		if(Session::get('role') != "2"){
			Session::flash('id',$id);
			Session::put('flag', 'delete');
			return Redirect::to('invoice/confirm');
		}else{
			return Redirect::to('/logout');
		}
	}
}
