<?php

class SchoolTest extends TestCase {

	/**
	 * A basic functional test example.
	 *
	 * @return void
	 */
	public function testIndexResponseOk()
	{
		$this->call('GET', '/login');
		
		$this->assertResponseOk();
	}

}
