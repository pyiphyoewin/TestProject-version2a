-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2014 at 08:42 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendances`
--

CREATE TABLE IF NOT EXISTS `attendances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `courseId` int(11) NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userApprovedId` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `attendances`
--

INSERT INTO `attendances` (`id`, `userId`, `courseId`, `status`, `userApprovedId`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 'approved', 1, '2014-08-14 11:05:42', '2014-08-15 11:05:42'),
(2, 2, 2, 'approved', 1, '2014-06-15 11:05:42', '2014-08-15 11:05:42'),
(3, 3, 1, 'approved', 1, '2014-06-15 11:05:42', '2014-08-15 12:32:54');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userId` int(11) NOT NULL,
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  `days` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `optionalDays` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sessions` int(11) NOT NULL,
  `optionalSessions` int(11) NOT NULL,
  `monthlyFee` int(11) NOT NULL,
  `sessionFee` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `name`, `userId`, `startDate`, `endDate`, `startTime`, `endTime`, `days`, `optionalDays`, `sessions`, `optionalSessions`, `monthlyFee`, `sessionFee`, `created_at`, `updated_at`) VALUES
(1, 'courseone', 1, '2014-09-12', '2014-12-12', '17:30:00', '19:30:00', 'Mon,Tue', 'Sat', 24, 12, 300, 10, '2014-08-15 11:05:42', '2014-08-15 11:05:42'),
(2, 'coursetwo', 1, '2014-09-12', '2014-12-12', '17:30:00', '19:30:00', 'Mon,Tue', 'Sat', 24, 12, 400, 10, '2014-08-15 11:05:42', '2014-08-15 11:05:42');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE IF NOT EXISTS `invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `courseId` int(11) NOT NULL,
  `sessions` int(11) NOT NULL,
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  `fees` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `userId`, `courseId`, `sessions`, `startDate`, `endDate`, `fees`, `created_at`, `updated_at`) VALUES
(2, 2, 1, 1, '2014-08-01', '2014-08-31', 380, '2014-08-15 11:55:20', '2014-08-15 11:55:20'),
(3, 2, 1, 1, '2014-06-01', '2014-08-31', 1140, '2014-08-16 22:30:07', '2014-08-16 22:30:07');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_08_10_171001_create_invoices_table', 1),
('2014_08_10_174836_create_courses_table', 1),
('2014_08_10_183810_create_attendances_table', 1),
('2014_08_11_024605_create_users_table', 1),
('2014_08_11_025625_create_user_course_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nrc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `birthday` date NOT NULL,
  `phone` int(11) NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role` int(11) NOT NULL,
  `remember_token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `nrc`, `email`, `birthday`, `phone`, `address`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'tutorone', '$2y$10$rtsMhnSK342pP6h4twtcM.K4aO7JqX98VXrWCuwCgXd3SrCbyf4KG', 'MA766667', 'tutorone@test.com', '1990-05-12', 876567789, 'no.7,tone street,tone city', 1, 'BJqiJLm84tiVH2QmuiqE2W3ZpbPxFqcwopoBQOncbvkhMaGJ4UJnVqmkZHJP', '2014-08-15 11:05:41', '2014-08-15 12:36:07'),
(2, 'studentone', '$2y$10$miwyhcdTPtx9vesnhnMQ1eH9leTNqO18FsnhOqQpf9u8c4iaDgu8e', 'MA87979', 'studentone@test.com', '1990-05-12', 997878789, 'no.9,one street,one city', 2, 'CNyDnjxNl86DSyrI8xzS7CliD0HyowFaToJtOXXveZQaLSO0h6gYOiKUQQX5', '2014-08-15 11:05:41', '2014-08-15 12:15:54'),
(3, 'studenttwo', '$2y$10$S0cZRO5UIm5TLZtJwvFSi.LwkQvDEFpLeONjlVnVSV65sF5FhWEHu', 'MA899329', 'studenttwo@test.com', '1990-05-12', 2147483647, 'no.10,one street,one city', 2, '', '2014-08-15 11:05:41', '2014-08-15 11:05:41');

-- --------------------------------------------------------

--
-- Table structure for table `user_course`
--

CREATE TABLE IF NOT EXISTS `user_course` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `courseId` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_course`
--

INSERT INTO `user_course` (`id`, `userId`, `courseId`, `created_at`, `updated_at`) VALUES
(1, 2, 1, '2014-08-15 11:05:42', '2014-08-15 11:05:42'),
(2, 2, 2, '2014-08-15 11:05:42', '2014-08-15 11:05:42'),
(3, 3, 1, '2014-08-15 11:05:42', '2014-08-15 11:05:42');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
